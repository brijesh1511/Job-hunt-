export class User {
    
    userId:string;
    firstName:string;
    lastName:string;
    password:string;
}
