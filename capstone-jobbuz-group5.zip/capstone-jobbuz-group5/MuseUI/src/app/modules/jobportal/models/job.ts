export class Job {
  public  id:string;
  public   jobId:string;
  public  name:string;
  public   publishedDate:string;
  public  location:string;
  public  company:string;
  public  status:string = "PENDING";
  public   userId:string;
}
